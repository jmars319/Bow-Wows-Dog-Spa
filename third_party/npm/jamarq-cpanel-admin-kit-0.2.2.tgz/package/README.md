# cPanel Admin Kit

Shared React admin UI foundation for JAMARQ cPanel websites.

This package provides reusable, site-themeable admin primitives:

- admin shell, sidebar, and guarded layout helpers
- status badges, notices, modal and confirmation dialog components
- system check cards and page layout
- toast provider and hook
- rich text editor and sanitized preview shell
- media card/grid primitives
- preview links, publish-state badges, ordering controls, task lists, usage shortcuts, and alt-text reminders

The package does not contain client-specific navigation, copy, API routes, schemas, or business workflows.

## Install In A Site Repo

Use the private Git dependency from a tagged release:

```json
{
  "dependencies": {
    "@jamarq/cpanel-admin-kit": "git+ssh://git@github.com/jmars319/cpanel-admin-kit.git#v0.1.2"
  }
}
```

Import only the subpath you need where practical:

```tsx
import { AdminShell } from '@jamarq/cpanel-admin-kit/admin-shell';
import { PreviewLink, SortOrderControls } from '@jamarq/cpanel-admin-kit/convenience';
import '@jamarq/cpanel-admin-kit/styles.css';
```

## Verify

```bash
npm ci
npm run lint
npm run typecheck
npm run test
npm run build
npm run verify
just security
```

## Local Standards

- Use Node 22 and npm 11. `mise` and `.nvmrc` are both provided for local activation.
- `just verify` runs the package verification command.
- `just security` runs GitHub Actions validation plus OSV scanning.
- Build output, dependency folders, local env files, logs, and secrets stay out of Git.
- Publish versions through Git tags and private Git dependencies; do not add client-specific code to this package.
