<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Storage;

final class StorageConfig
{
    /** @param array<string, string|null> $env */
    public function __construct(private array $env)
    {
    }

    public function provider(): string
    {
        $provider = strtolower(trim((string) ($this->env['MEDIA_STORAGE_PROVIDER'] ?? 'local')));
        return $provider === '' ? 'local' : $provider;
    }

    public function r2Configured(): bool
    {
        foreach (['R2_ACCOUNT_ID', 'R2_BUCKET', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY'] as $key) {
            if (trim((string) ($this->env[$key] ?? '')) === '') {
                return false;
            }
        }

        return true;
    }

    /** @return array<string, mixed> */
    public function systemCheckDetails(): array
    {
        return [
            'active_provider' => $this->provider(),
            'r2_configured' => $this->r2Configured(),
            'r2_status' => $this->r2Configured() ? 'ready_for_future_switch' : 'future_migration_not_configured',
        ];
    }
}

