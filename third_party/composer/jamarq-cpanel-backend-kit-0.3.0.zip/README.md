# cPanel Backend Kit

Shared PHP backend foundation for JAMARQ cPanel websites.

This package provides framework-light primitives for GoDaddy/cPanel PHP sites:

- environment and configuration loading
- HTTP request/response and JSON response helpers
- a small route dispatcher with route groups and middleware
- controller and auth guard helpers for compatibility-first site rewrites
- PDO convenience helpers
- validation, audit logging, upload validation, media fallback resolution
- local media storage interfaces with future R2 configuration checks
- system checks and SQL migration utilities

The package intentionally does not contain client-specific routes, schemas, payment logic, or business workflows.

## Requirements

- PHP 8.3+
- Composer 2+

## Install In A Site Repo

Add the private VCS repository to the site backend `composer.json`:

```json
{
  "repositories": [
    {
      "type": "vcs",
      "url": "https://github.com/jmars319/cpanel-backend-kit"
    }
  ],
  "require": {
    "jamarq/cpanel-backend-kit": "^0.2"
  }
}
```

Run Composer locally before building the cPanel deploy zip. Deploy artifacts should include `api/vendor` and should not require Composer to run on the server.

## Storage Providers

The package is local-storage first. `LocalStorageAdapter` writes to the existing cPanel uploads tree, while `StorageConfig` exposes future R2 readiness without enabling R2. Site repos may document these future-only keys, but should not add production R2 values until the migration pass:

- `MEDIA_STORAGE_PROVIDER=local`
- `R2_ACCOUNT_ID`
- `R2_BUCKET`
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`
- `R2_PUBLIC_BASE_URL`

## Verify

```bash
composer install
composer lint
composer test
composer verify
```
