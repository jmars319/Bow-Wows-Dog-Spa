<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend;

use RuntimeException;

final class Config
{
    /** @param array<string, mixed> $values */
    public function __construct(private array $values = [])
    {
    }

    /** @param array<string, mixed> $defaults */
    public static function fromEnv(array $defaults = []): self
    {
        return new self(array_merge($defaults, $_ENV, $_SERVER));
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->values[$key] ?? $default;
    }

    public function string(string $key, string $default = ''): string
    {
        $value = $this->get($key, $default);
        return is_scalar($value) ? (string) $value : $default;
    }

    public function int(string $key, int $default = 0): int
    {
        $value = $this->get($key, $default);
        return is_numeric($value) ? (int) $value : $default;
    }

    public function bool(string $key, bool $default = false): bool
    {
        $value = $this->get($key, $default);
        if (is_bool($value)) {
            return $value;
        }

        $parsed = filter_var($value, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
        return $parsed ?? $default;
    }

    public function required(string $key): string
    {
        $value = $this->string($key);
        if ($value === '') {
            throw new RuntimeException(sprintf('Missing required configuration value: %s', $key));
        }

        return $value;
    }

    /** @return array<string, mixed> */
    public function all(): array
    {
        return $this->values;
    }
}
