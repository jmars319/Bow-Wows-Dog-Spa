<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Audit;

use Throwable;

final class AuditLogger
{
    public function __construct(private mixed $writer = null)
    {
    }

    /** @param array<string, mixed> $context @param array<string, mixed>|null $user */
    public function log(string $action, array $context = [], ?array $user = null): bool
    {
        if (!is_callable($this->writer)) {
            return false;
        }

        try {
            (string) ($this->writer)($action, $context, $user);
            return true;
        } catch (Throwable) {
            return false;
        }
    }
}
