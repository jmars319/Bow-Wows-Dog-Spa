<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Storage;

final class StorageConfig
{
    /** @param array<string, string|null> $env */
    public function __construct(private array $env)
    {
    }

    public function provider(): string
    {
        $provider = strtolower(trim((string) ($this->env['MEDIA_STORAGE_PROVIDER'] ?? 'local')));
        return $provider === '' ? 'local' : $provider;
    }

    public function r2Configured(): bool
    {
        foreach (['R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY'] as $key) {
            if (trim((string) ($this->env[$key] ?? '')) === '') {
                return false;
            }
        }

        return $this->r2Endpoint() !== null
            && ($this->publicBucket() !== null || $this->privateBucket() !== null);
    }

    public function r2Endpoint(): ?string
    {
        $endpoint = trim((string) ($this->env['R2_ENDPOINT'] ?? ''));
        if ($endpoint !== '') {
            return rtrim($endpoint, '/');
        }

        $accountId = trim((string) ($this->env['R2_ACCOUNT_ID'] ?? ''));
        if ($accountId === '') {
            return null;
        }

        return 'https://' . $accountId . '.r2.cloudflarestorage.com';
    }

    public function accessKeyId(): ?string
    {
        $value = trim((string) ($this->env['R2_ACCESS_KEY_ID'] ?? ''));
        return $value === '' ? null : $value;
    }

    public function secretAccessKey(): ?string
    {
        $value = trim((string) ($this->env['R2_SECRET_ACCESS_KEY'] ?? ''));
        return $value === '' ? null : $value;
    }

    public function publicBucket(): ?string
    {
        return $this->bucket('R2_PUBLIC_BUCKET');
    }

    public function privateBucket(): ?string
    {
        return $this->bucket('R2_PRIVATE_BUCKET');
    }

    public function publicBaseUrl(): ?string
    {
        $value = trim((string) ($this->env['R2_PUBLIC_BASE_URL'] ?? ''));
        return $value === '' ? null : rtrim($value, '/');
    }

    /** @return array<string, mixed> */
    public function systemCheckDetails(): array
    {
        return [
            'active_provider' => $this->provider(),
            'r2_configured' => $this->r2Configured(),
            'r2_public_bucket_configured' => $this->publicBucket() !== null,
            'r2_private_bucket_configured' => $this->privateBucket() !== null,
            'r2_public_base_url_configured' => $this->publicBaseUrl() !== null,
            'r2_status' => $this->r2Configured() ? 'ready' : 'not_configured',
        ];
    }

    private function bucket(string $key): ?string
    {
        $value = trim((string) ($this->env[$key] ?? ''));
        if ($value === '') {
            $value = trim((string) ($this->env['R2_BUCKET'] ?? ''));
        }

        return $value === '' ? null : $value;
    }
}
