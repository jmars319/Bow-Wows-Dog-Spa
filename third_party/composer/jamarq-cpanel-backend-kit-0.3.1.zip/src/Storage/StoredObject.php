<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Storage;

final class StoredObject
{
    /** @param array<string, mixed> $metadata */
    public function __construct(
        public readonly string $provider,
        public readonly string $key,
        public readonly ?string $url,
        public readonly int $size,
        public readonly ?string $checksum = null,
        public readonly array $metadata = []
    ) {
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'provider' => $this->provider,
            'key' => $this->key,
            'url' => $this->url,
            'size' => $this->size,
            'checksum' => $this->checksum,
            'metadata' => $this->metadata,
        ];
    }
}

