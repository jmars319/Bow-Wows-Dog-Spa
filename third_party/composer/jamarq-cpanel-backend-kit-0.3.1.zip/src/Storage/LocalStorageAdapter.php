<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Storage;

use RuntimeException;

final class LocalStorageAdapter implements StorageAdapterInterface
{
    public function __construct(
        private string $rootDirectory,
        private string $publicBaseUrl = '/uploads'
    ) {
        $this->rootDirectory = rtrim($rootDirectory, '/');
        $this->publicBaseUrl = '/' . trim($publicBaseUrl, '/');
    }

    public function provider(): string
    {
        return 'local';
    }

    public function exists(string $key): bool
    {
        return is_file($this->pathFor($key));
    }

    public function url(string $key): ?string
    {
        $key = $this->cleanKey($key);
        return $key === '' ? null : $this->publicBaseUrl . '/' . $key;
    }

    /** @param array<string, mixed> $metadata */
    public function putFile(string $key, string $sourcePath, array $metadata = []): StoredObject
    {
        if (!is_file($sourcePath)) {
            throw new RuntimeException('Source file does not exist.');
        }

        $target = $this->pathFor($key);
        $directory = dirname($target);
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new RuntimeException('Could not create storage directory.');
        }

        if (!copy($sourcePath, $target)) {
            throw new RuntimeException('Could not store uploaded file.');
        }

        $size = filesize($target);
        $checksum = hash_file('sha256', $target);

        return new StoredObject(
            $this->provider(),
            $this->cleanKey($key),
            $this->url($key),
            is_int($size) ? $size : 0,
            is_string($checksum) ? $checksum : null,
            $metadata
        );
    }

    public function delete(string $key): bool
    {
        $path = $this->pathFor($key);
        return is_file($path) ? unlink($path) : true;
    }

    private function pathFor(string $key): string
    {
        $key = $this->cleanKey($key);
        if ($key === '' || str_contains($key, '..')) {
            throw new RuntimeException('Invalid storage key.');
        }

        return $this->rootDirectory . '/' . $key;
    }

    private function cleanKey(string $key): string
    {
        return trim(str_replace('\\', '/', $key), '/');
    }
}

