<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Storage;

interface StorageAdapterInterface
{
    public function provider(): string;

    public function exists(string $key): bool;

    public function url(string $key): ?string;

    /** @param array<string, mixed> $metadata */
    public function putFile(string $key, string $sourcePath, array $metadata = []): StoredObject;

    public function delete(string $key): bool;
}

