<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Storage;

use RuntimeException;

final class R2StorageAdapter implements StorageAdapterInterface
{
    private string $endpoint;
    private ?string $publicBaseUrl;

    public function __construct(
        string $endpoint,
        private string $accessKeyId,
        private string $secretAccessKey,
        private string $bucket,
        ?string $publicBaseUrl = null,
        private string $region = 'auto'
    ) {
        $this->endpoint = rtrim($endpoint, '/');
        $this->publicBaseUrl = $publicBaseUrl === null ? null : rtrim($publicBaseUrl, '/');
        $this->bucket = trim($bucket);

        if ($this->endpoint === '' || $this->accessKeyId === '' || $this->secretAccessKey === '' || $this->bucket === '') {
            throw new RuntimeException('R2 storage is not configured.');
        }
    }

    public function provider(): string
    {
        return 'r2';
    }

    public function exists(string $key): bool
    {
        $response = $this->request('HEAD', $key);
        if ($response['status'] === 404) {
            return false;
        }

        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new RuntimeException('Could not check R2 object status.');
        }

        return true;
    }

    public function url(string $key): ?string
    {
        $key = $this->cleanKey($key);
        return $key === '' || $this->publicBaseUrl === null ? null : $this->publicBaseUrl . '/' . $key;
    }

    /** @param array<string, mixed> $metadata */
    public function putFile(string $key, string $sourcePath, array $metadata = []): StoredObject
    {
        if (!is_file($sourcePath)) {
            throw new RuntimeException('Source file does not exist.');
        }

        $contents = file_get_contents($sourcePath);
        if (!is_string($contents)) {
            throw new RuntimeException('Could not read source file.');
        }

        $headers = [];
        if (isset($metadata['content_type']) && is_string($metadata['content_type']) && $metadata['content_type'] !== '') {
            $headers['content-type'] = $metadata['content_type'];
        }
        if (isset($metadata['cache_control']) && is_string($metadata['cache_control']) && $metadata['cache_control'] !== '') {
            $headers['cache-control'] = $metadata['cache_control'];
        }

        foreach ($metadata as $name => $value) {
            if (!str_starts_with((string) $name, 'meta_') || !is_scalar($value)) {
                continue;
            }
            $headers['x-amz-meta-' . strtolower(str_replace('_', '-', substr((string) $name, 5)))] = (string) $value;
        }

        $response = $this->request('PUT', $key, $contents, $headers);
        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new RuntimeException('Could not store R2 object.');
        }

        $size = filesize($sourcePath);
        $checksum = hash_file('sha256', $sourcePath);

        return new StoredObject(
            $this->provider(),
            $this->cleanKey($key),
            $this->url($key),
            is_int($size) ? $size : 0,
            is_string($checksum) ? $checksum : null,
            $metadata + ['bucket' => $this->bucket]
        );
    }

    public function delete(string $key): bool
    {
        $response = $this->request('DELETE', $key);
        return $response['status'] === 404 || ($response['status'] >= 200 && $response['status'] < 300);
    }

    /** @param array<string, string> $headers */
    private function request(string $method, string $key, string $body = '', array $headers = []): array
    {
        $key = $this->cleanKey($key);
        if ($key === '' || str_contains($key, '..')) {
            throw new RuntimeException('Invalid storage key.');
        }

        $url = $this->endpoint . '/' . rawurlencode($this->bucket) . '/' . $this->encodeKey($key);
        $signedHeaders = $this->signedHeaders($method, $url, $body, $headers);
        $context = stream_context_create([
            'http' => [
                'method' => $method,
                'header' => $this->formatHeaders($signedHeaders),
                'content' => $method === 'PUT' ? $body : '',
                'ignore_errors' => true,
                'timeout' => 60,
            ],
        ]);

        $responseBody = @file_get_contents($url, false, $context);
        $status = $this->statusFromHeaders($http_response_header ?? []);

        return [
            'status' => $status,
            'body' => is_string($responseBody) ? $responseBody : '',
            'headers' => $http_response_header ?? [],
        ];
    }

    /** @param array<string, string> $headers */
    private function signedHeaders(string $method, string $url, string $body, array $headers): array
    {
        $parts = parse_url($url);
        $host = is_string($parts['host'] ?? null) ? $parts['host'] : '';
        $path = is_string($parts['path'] ?? null) ? $parts['path'] : '/';
        $query = is_string($parts['query'] ?? null) ? $parts['query'] : '';
        $timestamp = gmdate('Ymd\THis\Z');
        $date = substr($timestamp, 0, 8);
        $payloadHash = hash('sha256', $body);

        $normalized = [
            'host' => $host,
            'x-amz-content-sha256' => $payloadHash,
            'x-amz-date' => $timestamp,
        ];

        foreach ($headers as $name => $value) {
            $normalized[strtolower($name)] = trim($value);
        }

        ksort($normalized);
        $canonicalHeaders = '';
        foreach ($normalized as $name => $value) {
            $canonicalHeaders .= $name . ':' . preg_replace('/\s+/', ' ', $value) . "\n";
        }

        $signedHeaderNames = implode(';', array_keys($normalized));
        $canonicalRequest = implode("\n", [
            strtoupper($method),
            $path,
            $query,
            $canonicalHeaders,
            $signedHeaderNames,
            $payloadHash,
        ]);

        $credentialScope = $date . '/' . $this->region . '/s3/aws4_request';
        $stringToSign = implode("\n", [
            'AWS4-HMAC-SHA256',
            $timestamp,
            $credentialScope,
            hash('sha256', $canonicalRequest),
        ]);

        $signature = hash_hmac('sha256', $stringToSign, $this->signingKey($date));
        $normalized['authorization'] = sprintf(
            'AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s',
            $this->accessKeyId,
            $credentialScope,
            $signedHeaderNames,
            $signature
        );

        return $normalized;
    }

    private function signingKey(string $date): string
    {
        $dateKey = hash_hmac('sha256', $date, 'AWS4' . $this->secretAccessKey, true);
        $dateRegionKey = hash_hmac('sha256', $this->region, $dateKey, true);
        $dateRegionServiceKey = hash_hmac('sha256', 's3', $dateRegionKey, true);
        return hash_hmac('sha256', 'aws4_request', $dateRegionServiceKey, true);
    }

    /** @param array<string, string> $headers */
    private function formatHeaders(array $headers): string
    {
        $lines = [];
        foreach ($headers as $name => $value) {
            $lines[] = $name . ': ' . $value;
        }

        return implode("\r\n", $lines);
    }

    /** @param array<int, string> $headers */
    private function statusFromHeaders(array $headers): int
    {
        $first = $headers[0] ?? '';
        if (preg_match('/\s(\d{3})\s/', $first, $matches) === 1) {
            return (int) $matches[1];
        }

        return 0;
    }

    private function encodeKey(string $key): string
    {
        return implode('/', array_map(rawurlencode(...), explode('/', $key)));
    }

    private function cleanKey(string $key): string
    {
        return trim(str_replace('\\', '/', $key), '/');
    }
}
