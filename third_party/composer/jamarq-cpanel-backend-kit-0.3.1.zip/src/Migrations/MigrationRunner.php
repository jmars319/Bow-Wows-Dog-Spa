<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Migrations;

use Jamarq\CpanelBackend\Database\Database;

final class MigrationRunner
{
    public function __construct(
        private Database $database,
        private string $migrationDirectory,
        private string $table = 'schema_migrations'
    ) {
    }

    public function ensureTable(): void
    {
        $this->database->execute(sprintf(
            'CREATE TABLE IF NOT EXISTS %s (migration VARCHAR(255) PRIMARY KEY, applied_at DATETIME NOT NULL)',
            $this->table
        ));
    }

    /** @return array<int, string> */
    public function applied(): array
    {
        $this->ensureTable();
        $rows = $this->database->fetchAll(sprintf('SELECT migration FROM %s ORDER BY migration', $this->table));
        return array_map(static fn (array $row): string => (string) $row['migration'], $rows);
    }

    /** @return array<int, string> */
    public function pending(): array
    {
        $applied = array_flip($this->applied());
        $files = glob(rtrim($this->migrationDirectory, '/') . '/*.sql') ?: [];
        sort($files);

        return array_values(array_filter($files, static function (string $file) use ($applied): bool {
            return !isset($applied[basename($file)]);
        }));
    }

    /** @return array<int, string> */
    public function runPending(): array
    {
        $ran = [];
        foreach ($this->pending() as $file) {
            $migration = basename($file);
            $sql = (string) file_get_contents($file);

            $this->database->transaction(function (Database $database) use ($sql, $migration): void {
                foreach ($this->splitStatements($sql) as $statement) {
                    $database->execute($statement);
                }
                $database->execute(
                    sprintf('INSERT INTO %s (migration, applied_at) VALUES (:migration, CURRENT_TIMESTAMP)', $this->table),
                    ['migration' => $migration]
                );
            });

            $ran[] = $migration;
        }

        return $ran;
    }

    /** @return array<int, string> */
    private function splitStatements(string $sql): array
    {
        $statements = preg_split('/;\s*(?:\r?\n|$)/', $sql) ?: [];
        return array_values(array_filter(array_map('trim', $statements), static fn (string $statement): bool => $statement !== ''));
    }
}
