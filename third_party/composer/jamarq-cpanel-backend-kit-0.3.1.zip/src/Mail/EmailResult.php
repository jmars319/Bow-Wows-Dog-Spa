<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Mail;

final class EmailResult
{
    /** @param array<string, mixed> $metadata */
    public function __construct(
        private bool $sent,
        private ?string $error = null,
        private array $metadata = []
    ) {
    }

    /** @param array<string, mixed> $metadata */
    public static function sent(array $metadata = []): self
    {
        return new self(true, null, $metadata);
    }

    /** @param array<string, mixed> $metadata */
    public static function failed(string $error, array $metadata = []): self
    {
        return new self(false, $error, $metadata);
    }

    public function wasSent(): bool
    {
        return $this->sent;
    }

    public function error(): ?string
    {
        return $this->error;
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'sent' => $this->sent,
            'error' => $this->error,
            'metadata' => $this->metadata,
        ];
    }
}
