<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Validation;

final class Validator
{
    /** @var array<string, string> */
    private array $errors = [];

    /** @param array<string, mixed> $data */
    public function __construct(private array $data)
    {
    }

    /** @param array<string, mixed> $data */
    public static function check(array $data): self
    {
        return new self($data);
    }

    public function required(string $field, ?string $message = null): self
    {
        $value = $this->data[$field] ?? null;
        if ($value === null || (is_string($value) && trim($value) === '')) {
            $this->errors[$field] = $message ?? sprintf('%s is required.', $field);
        }

        return $this;
    }

    public function email(string $field, ?string $message = null): self
    {
        $value = $this->data[$field] ?? null;
        if ($value !== null && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = $message ?? sprintf('%s must be a valid email address.', $field);
        }

        return $this;
    }

    public function maxLength(string $field, int $max, ?string $message = null): self
    {
        $value = $this->data[$field] ?? null;
        if (is_string($value) && mb_strlen($value) > $max) {
            $this->errors[$field] = $message ?? sprintf('%s must be %d characters or fewer.', $field, $max);
        }

        return $this;
    }

    /** @param array<int, string> $allowed */
    public function oneOf(string $field, array $allowed, ?string $message = null): self
    {
        $value = $this->data[$field] ?? null;
        if ($value !== null && !in_array((string) $value, $allowed, true)) {
            $this->errors[$field] = $message ?? sprintf('%s is not an allowed value.', $field);
        }

        return $this;
    }

    public function passes(): bool
    {
        return $this->errors === [];
    }

    /** @return array<string, string> */
    public function errors(): array
    {
        return $this->errors;
    }
}
