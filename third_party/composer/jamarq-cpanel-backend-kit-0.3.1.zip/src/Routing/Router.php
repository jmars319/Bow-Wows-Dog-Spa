<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Routing;

use Jamarq\CpanelBackend\Http\JsonResponse;
use Jamarq\CpanelBackend\Http\Request;
use Jamarq\CpanelBackend\Http\Response;
use Throwable;

final class Router
{
    /** @var array<int, array{method: string, path: string, pattern: string, handler: callable, middleware: array<int, callable>}> */
    private array $routes = [];

    /** @var array<int, string> */
    private array $prefixStack = [];

    /** @var array<int, callable> */
    private array $middlewareStack = [];

    /** @var null|callable(Request): Response */
    private $notFoundHandler = null;

    /** @var null|callable(Throwable, Request): Response */
    private $exceptionHandler = null;

    public function get(string $path, callable $handler): self
    {
        return $this->add('GET', $path, $handler);
    }

    public function post(string $path, callable $handler): self
    {
        return $this->add('POST', $path, $handler);
    }

    public function put(string $path, callable $handler): self
    {
        return $this->add('PUT', $path, $handler);
    }

    public function patch(string $path, callable $handler): self
    {
        return $this->add('PATCH', $path, $handler);
    }

    public function delete(string $path, callable $handler): self
    {
        return $this->add('DELETE', $path, $handler);
    }

    public function any(string $path, callable $handler): self
    {
        return $this->add('ANY', $path, $handler);
    }

    public function options(string $path, callable $handler): self
    {
        return $this->add('OPTIONS', $path, $handler);
    }

    public function group(string $prefix, callable $callback): self
    {
        $this->prefixStack[] = $this->normalizePath($prefix);

        try {
            $callback($this);
        } finally {
            array_pop($this->prefixStack);
        }

        return $this;
    }

    public function withMiddleware(callable $middleware, callable $callback): self
    {
        $this->middlewareStack[] = $middleware;

        try {
            $callback($this);
        } finally {
            array_pop($this->middlewareStack);
        }

        return $this;
    }

    public function add(string $method, string $path, callable $handler): self
    {
        $path = $this->normalizePath($this->currentPrefix() . '/' . ltrim($path, '/'));
        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => $path,
            'pattern' => $this->compilePattern($path),
            'handler' => $handler,
            'middleware' => $this->middlewareStack,
        ];

        return $this;
    }

    public function onNotFound(callable $handler): self
    {
        $this->notFoundHandler = $handler;
        return $this;
    }

    public function onException(callable $handler): self
    {
        $this->exceptionHandler = $handler;
        return $this;
    }

    public function dispatch(Request $request): Response
    {
        foreach ($this->routes as $route) {
            if ($route['method'] !== 'ANY' && $route['method'] !== $request->method()) {
                continue;
            }

            if (!preg_match($route['pattern'], $this->normalizePath($request->path()), $matches)) {
                continue;
            }

            $params = array_filter($matches, static fn ($key): bool => !is_int($key), ARRAY_FILTER_USE_KEY);
            $routeRequest = $request->withAttribute('routeParams', $params);

            try {
                return $this->runRoute($route['handler'], $route['middleware'], $routeRequest, $params);
            } catch (Throwable $error) {
                if ($this->exceptionHandler !== null) {
                    return $this->normalizeHandlerResult(($this->exceptionHandler)($error, $request));
                }

                return JsonResponse::error('Internal server error', 500, [
                    'reference' => substr(hash('sha256', $error->getMessage() . microtime(true)), 0, 16),
                ]);
            }
        }

        if ($this->notFoundHandler !== null) {
            return $this->normalizeHandlerResult(($this->notFoundHandler)($request));
        }

        return JsonResponse::error('Not found', 404);
    }

    /**
     * @param array<int, callable> $middleware
     * @param array<string, string> $params
     */
    private function runRoute(callable $handler, array $middleware, Request $request, array $params): Response
    {
        $next = fn (Request $routeRequest): Response => $this->normalizeHandlerResult($handler($routeRequest, $params));

        foreach (array_reverse($middleware) as $layer) {
            $next = fn (Request $routeRequest): Response => $this->normalizeHandlerResult($layer($routeRequest, $next));
        }

        return $next($request);
    }

    private function normalizeHandlerResult(mixed $result): Response
    {
        if ($result instanceof Response) {
            return $result;
        }

        if (is_array($result)) {
            return new JsonResponse($result);
        }

        if ($result === null) {
            return new Response('', 204);
        }

        return Response::text((string) $result);
    }

    private function currentPrefix(): string
    {
        if ($this->prefixStack === []) {
            return '';
        }

        return implode('', array_map(
            static fn (string $prefix): string => $prefix === '/' ? '' : $prefix,
            $this->prefixStack
        ));
    }

    private function normalizePath(string $path): string
    {
        $path = '/' . trim($path, '/');
        return $path === '/' ? '/' : rtrim($path, '/');
    }

    private function compilePattern(string $path): string
    {
        $quoted = preg_quote($path, '#');
        $pattern = preg_replace('#\\\\\{([A-Za-z_][A-Za-z0-9_]*)\\\\\}#', '(?P<$1>[^/]+)', $quoted);
        $pattern = preg_replace('#\\\\:([A-Za-z_][A-Za-z0-9_]*)#', '(?P<$1>[^/]+)', $pattern);
        return '#^' . ($pattern ?: '/') . '$#';
    }
}
