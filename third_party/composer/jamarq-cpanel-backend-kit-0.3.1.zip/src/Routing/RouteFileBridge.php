<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Routing;

use Jamarq\CpanelBackend\Http\Request;
use Jamarq\CpanelBackend\Http\Response;
use RuntimeException;

final class RouteFileBridge
{
    /** @var array<int, array{method: string, path: string, file: string, query: array<string, string>}> */
    private array $routes = [];

    public function __construct(private Router $router, private string $baseDir)
    {
    }

    /** @param array<string, string> $query */
    public function map(string $method, string $path, string $file, array $query = []): self
    {
        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => $path,
            'file' => $file,
            'query' => $query,
        ];

        $this->router->add($method, $path, fn (Request $request, array $params): Response => $this->requireRouteFile($file, $params + $query));

        return $this;
    }

    /** @param array<string, string> $mapping */
    public function exact(array $mapping, string $method = 'ANY'): self
    {
        foreach ($mapping as $path => $file) {
            $this->map($method, $path, $file);
        }

        return $this;
    }

    /** @param array<string, string> $params */
    private function requireRouteFile(string $file, array $params): Response
    {
        $path = $this->baseDir . '/' . ltrim($file, '/');
        if (!is_file($path)) {
            throw new RuntimeException('Route file not found: ' . $file);
        }

        foreach ($params as $key => $value) {
            $_GET[$key] = $value;
        }

        ob_start();
        require $path;
        $body = ob_get_clean();

        $status = http_response_code();
        if (!$status || $status < 100) {
            $status = 200;
        }

        return new Response((string) $body, $status);
    }

    /** @return array<int, array{method: string, path: string, file: string, query: array<string, string>}> */
    public function routes(): array
    {
        return $this->routes;
    }
}
