<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\System;

use Throwable;

final class SystemChecks
{
    /** @var array<int, SystemCheck> */
    private array $checks = [];

    public function add(SystemCheck $check): self
    {
        $this->checks[] = $check;
        return $this;
    }

    /** @param array<string, mixed> $details */
    public function ok(string $id, string $label, string $message, array $details = []): self
    {
        return $this->add(new SystemCheck($id, $label, SystemCheck::OK, $message, $details));
    }

    /** @param array<string, mixed> $details */
    public function warning(string $id, string $label, string $message, array $details = [], ?string $action = null): self
    {
        return $this->add(new SystemCheck($id, $label, SystemCheck::WARNING, $message, $details, $action));
    }

    /** @param array<string, mixed> $details */
    public function error(string $id, string $label, string $message, array $details = [], ?string $action = null): self
    {
        return $this->add(new SystemCheck($id, $label, SystemCheck::ERROR, $message, $details, $action));
    }

    /** @param array<string, mixed> $details */
    public function info(string $id, string $label, string $message, array $details = []): self
    {
        return $this->add(new SystemCheck($id, $label, SystemCheck::INFO, $message, $details));
    }

    public function probe(string $id, string $label, callable $callback): self
    {
        try {
            $result = $callback();
            if ($result instanceof SystemCheck) {
                return $this->add($result);
            }

            return $this->ok($id, $label, is_string($result) ? $result : 'Check passed.');
        } catch (Throwable $error) {
            return $this->error($id, $label, 'Check failed.', ['error' => $error->getMessage()]);
        }
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        $checks = array_map(static fn (SystemCheck $check): array => $check->toArray(), $this->checks);
        $hasErrors = array_reduce(
            $this->checks,
            static fn (bool $carry, SystemCheck $check): bool => $carry || $check->status() === SystemCheck::ERROR,
            false
        );

        return [
            'success' => !$hasErrors,
            'checks' => $checks,
        ];
    }
}
