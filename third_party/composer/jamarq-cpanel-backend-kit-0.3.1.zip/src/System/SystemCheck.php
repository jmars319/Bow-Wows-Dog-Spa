<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\System;

final class SystemCheck
{
    public const OK = 'ok';
    public const WARNING = 'warning';
    public const ERROR = 'error';
    public const INFO = 'info';

    /** @param array<string, mixed> $details */
    public function __construct(
        private string $id,
        private string $label,
        private string $status,
        private string $message,
        private array $details = [],
        private ?string $action = null
    ) {
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'label' => $this->label,
            'status' => $this->status,
            'message' => $this->message,
            'details' => $this->details,
            'action' => $this->action,
        ];
    }

    public function status(): string
    {
        return $this->status;
    }
}
