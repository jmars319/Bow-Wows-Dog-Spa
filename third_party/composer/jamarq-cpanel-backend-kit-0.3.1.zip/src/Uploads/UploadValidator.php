<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Uploads;

use finfo;

final class UploadValidator
{
    /** @var array<int, string> */
    private array $blockedExtensions = [
        'php', 'phtml', 'phar', 'cgi', 'pl', 'py', 'rb', 'js', 'mjs', 'html', 'htm',
        'svg', 'exe', 'dll', 'sh', 'bash', 'bat', 'cmd', 'com', 'scr', 'jar', 'zip',
        'rar', '7z', 'tar', 'gz',
    ];

    /** @var array<int, string> */
    private array $allowedExtensions = [
        'jpg', 'jpeg', 'png', 'webp', 'gif', 'pdf', 'txt', 'csv', 'doc', 'docx', 'xls', 'xlsx',
    ];

    /** @var array<int, string> */
    private array $allowedMimes = [
        'image/jpeg', 'image/png', 'image/webp', 'image/gif',
        'application/pdf', 'text/plain', 'text/csv',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];

    /** @param array<string, mixed> $options */
    public function __construct(private array $options = [])
    {
        $this->allowedExtensions = $options['allowed_extensions'] ?? $this->allowedExtensions;
        $this->allowedMimes = $options['allowed_mimes'] ?? $this->allowedMimes;
        $this->blockedExtensions = $options['blocked_extensions'] ?? $this->blockedExtensions;
    }

    /** @param array<string, mixed> $file @return array<int, string> */
    public function validate(array $file): array
    {
        $errors = [];
        $name = (string) ($file['name'] ?? '');
        $tmpName = (string) ($file['tmp_name'] ?? '');
        $size = (int) ($file['size'] ?? 0);
        $maxBytes = (int) ($this->options['max_bytes'] ?? 10 * 1024 * 1024);
        $uploadError = (int) ($file['error'] ?? UPLOAD_ERR_OK);

        if ($uploadError !== UPLOAD_ERR_OK) {
            $errors[] = 'Upload did not complete successfully.';
        }

        $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($extension === '' || in_array($extension, $this->blockedExtensions, true)) {
            $errors[] = 'File type is not allowed.';
        } elseif (!in_array($extension, $this->allowedExtensions, true)) {
            $errors[] = 'File extension is not allowed.';
        }

        if ($size <= 0) {
            $errors[] = 'File is empty.';
        } elseif ($size > $maxBytes) {
            $errors[] = 'File is too large.';
        }

        $mime = $this->detectMime($tmpName);
        if ($mime !== null && !in_array($mime, $this->allowedMimes, true)) {
            $errors[] = 'File content type is not allowed.';
        }

        return array_values(array_unique($errors));
    }

    private function detectMime(string $path): ?string
    {
        if ($path === '' || !is_file($path)) {
            return null;
        }

        $info = new finfo(FILEINFO_MIME_TYPE);
        $mime = $info->file($path);

        return is_string($mime) ? $mime : null;
    }
}
