<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend;

final class Dotenv
{
    /**
     * Load key/value pairs from a dotenv file into $_ENV, $_SERVER, and putenv.
     *
     * @return array<string, string>
     */
    public static function load(string $path, bool $override = false): array
    {
        if (!is_file($path) || !is_readable($path)) {
            return [];
        }

        $loaded = [];
        $lines = file($path, FILE_IGNORE_NEW_LINES);
        if ($lines === false) {
            return [];
        }

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            if (str_starts_with($line, 'export ')) {
                $line = trim(substr($line, 7));
            }

            $separator = strpos($line, '=');
            if ($separator === false) {
                continue;
            }

            $key = trim(substr($line, 0, $separator));
            $value = self::parseValue(trim(substr($line, $separator + 1)));

            if ($key === '' || (!self::missing($key) && !$override)) {
                continue;
            }

            $_ENV[$key] = $value;
            $_SERVER[$key] = $value;
            putenv($key . '=' . $value);
            $loaded[$key] = $value;
        }

        return $loaded;
    }

    private static function missing(string $key): bool
    {
        return !array_key_exists($key, $_ENV) && getenv($key) === false;
    }

    private static function parseValue(string $value): string
    {
        if ($value === '') {
            return '';
        }

        $quote = $value[0];
        if (($quote === '"' || $quote === "'") && str_ends_with($value, $quote)) {
            $value = substr($value, 1, -1);
            if ($quote === '"') {
                $value = str_replace(['\\n', '\\r', '\\"', '\\\\'], ["\n", "\r", '"', '\\'], $value);
            }
            return $value;
        }

        $commentStart = strpos($value, ' #');
        if ($commentStart !== false) {
            $value = substr($value, 0, $commentStart);
        }

        return trim($value);
    }
}
