<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Auth;

use Jamarq\CpanelBackend\Http\JsonResponse;
use Jamarq\CpanelBackend\Http\Request;
use Jamarq\CpanelBackend\Http\Response;

final class AuthGuard
{
    public function __construct(private AuthAdapterInterface $adapter)
    {
    }

    public function middleware(?string $permission = null): callable
    {
        return function (Request $request, callable $next) use ($permission): Response {
            $user = $this->adapter->userFromRequest($request);

            if ($user === null) {
                return JsonResponse::error('Authentication required.', 401);
            }

            if ($permission !== null && !$this->adapter->can($user, $permission)) {
                return JsonResponse::error('Permission denied.', 403);
            }

            return $next($request->withAttribute('authUser', $user));
        };
    }
}

