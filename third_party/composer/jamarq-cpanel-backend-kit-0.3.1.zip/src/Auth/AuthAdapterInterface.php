<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Auth;

use Jamarq\CpanelBackend\Http\Request;

interface AuthAdapterInterface
{
    /** @return array<string, mixed>|null */
    public function userFromRequest(Request $request): ?array;

    /** @param array<string, mixed> $user */
    public function can(array $user, string $permission): bool;
}
