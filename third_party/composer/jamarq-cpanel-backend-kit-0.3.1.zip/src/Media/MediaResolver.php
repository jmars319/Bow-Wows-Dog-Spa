<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Media;

final class MediaResolver
{
    /**
     * @return array{src: string|null, status: string, is_fallback: bool}
     */
    public function resolve(?string $uploadedUrl, ?string $fallbackUrl = null, ?callable $exists = null): array
    {
        $uploadedUrl = $this->cleanUrl($uploadedUrl);
        $fallbackUrl = $this->cleanUrl($fallbackUrl);

        if ($uploadedUrl !== null && ($exists === null || $exists($uploadedUrl) === true)) {
            return ['src' => $uploadedUrl, 'status' => 'uploaded', 'is_fallback' => false];
        }

        if ($fallbackUrl !== null && ($exists === null || $exists($fallbackUrl) === true)) {
            return ['src' => $fallbackUrl, 'status' => 'fallback', 'is_fallback' => true];
        }

        return ['src' => null, 'status' => 'missing', 'is_fallback' => false];
    }

    private function cleanUrl(?string $url): ?string
    {
        $url = is_string($url) ? trim($url) : '';
        return $url === '' ? null : $url;
    }
}
