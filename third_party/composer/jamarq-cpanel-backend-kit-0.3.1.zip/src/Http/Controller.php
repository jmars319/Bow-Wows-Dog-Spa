<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Http;

abstract class Controller
{
    /** @param array<string, mixed> $data */
    protected function ok(array $data = [], int $status = 200): JsonResponse
    {
        return JsonResponse::ok($data, $status);
    }

    /** @param array<string, mixed> $data */
    protected function created(array $data = []): JsonResponse
    {
        return JsonResponse::ok($data, 201);
    }

    /** @param array<string, mixed> $details */
    protected function error(string $message, int $status = 400, array $details = []): JsonResponse
    {
        return JsonResponse::error($message, $status, $details);
    }

    protected function noContent(): Response
    {
        return new Response('', 204);
    }
}

