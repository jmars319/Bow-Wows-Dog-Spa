<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Http;

final class Request
{
    /** @var array<string, string> */
    private array $normalizedHeaders = [];

    /**
     * @param array<string, mixed> $query
     * @param array<string, mixed> $headers
     * @param array<string, mixed> $files
     * @param array<string, mixed> $cookies
     * @param array<string, mixed> $server
     * @param array<string, mixed> $attributes
     */
    public function __construct(
        private string $method,
        private string $path,
        private array $query = [],
        private array $headers = [],
        private string $body = '',
        private array $files = [],
        private array $cookies = [],
        private array $server = [],
        private array $attributes = []
    ) {
        foreach ($headers as $key => $value) {
            if (is_scalar($value)) {
                $this->normalizedHeaders[strtolower((string) $key)] = (string) $value;
            }
        }
    }

    public static function fromGlobals(?string $basePath = null): self
    {
        $server = $_SERVER;
        $uri = (string) ($server['REQUEST_URI'] ?? '/');
        $path = (string) (parse_url($uri, PHP_URL_PATH) ?: '/');

        if ($basePath !== null && $basePath !== '' && str_starts_with($path, $basePath)) {
            $path = substr($path, strlen($basePath)) ?: '/';
        }

        return new self(
            strtoupper((string) ($server['REQUEST_METHOD'] ?? 'GET')),
            $path,
            $_GET,
            self::headersFromServer($server),
            (string) file_get_contents('php://input'),
            $_FILES,
            $_COOKIE,
            $server
        );
    }

    public function method(): string
    {
        return strtoupper($this->method);
    }

    public function path(): string
    {
        return $this->path === '' ? '/' : $this->path;
    }

    /** @return array<string, mixed> */
    public function query(): array
    {
        return $this->query;
    }

    public function input(string $key, mixed $default = null): mixed
    {
        $json = $this->json();
        if (array_key_exists($key, $json)) {
            return $json[$key];
        }

        return $this->query[$key] ?? $default;
    }

    public function header(string $key, ?string $default = null): ?string
    {
        return $this->normalizedHeaders[strtolower($key)] ?? $default;
    }

    public function body(): string
    {
        return $this->body;
    }

    /** @return array<string, mixed> */
    public function json(): array
    {
        if ($this->body === '') {
            return [];
        }

        $decoded = json_decode($this->body, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** @return array<string, mixed> */
    public function files(): array
    {
        return $this->files;
    }

    public function attribute(string $key, mixed $default = null): mixed
    {
        return $this->attributes[$key] ?? $default;
    }

    public function withAttribute(string $key, mixed $value): self
    {
        $copy = clone $this;
        $copy->attributes[$key] = $value;
        return $copy;
    }

    /** @param array<string, mixed> $server */
    private static function headersFromServer(array $server): array
    {
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
            if (is_array($headers)) {
                return $headers;
            }
        }

        $headers = [];
        foreach ($server as $key => $value) {
            if (!str_starts_with($key, 'HTTP_') || !is_scalar($value)) {
                continue;
            }

            $name = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
            $headers[$name] = (string) $value;
        }

        return $headers;
    }
}
