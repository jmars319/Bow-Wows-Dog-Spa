<?php

declare(strict_types=1);

namespace Jamarq\CpanelBackend\Http;

final class JsonResponse extends Response
{
    /** @param array<string, mixed> $payload */
    public function __construct(array $payload, int $status = 200)
    {
        parent::__construct(
            (string) json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            $status,
            ['Content-Type' => 'application/json; charset=utf-8']
        );
    }

    /** @param array<string, mixed> $data */
    public static function ok(array $data = [], int $status = 200): self
    {
        return new self(array_merge(['success' => true], $data), $status);
    }

    /** @param array<string, mixed> $details */
    public static function error(string $message, int $status = 400, array $details = []): self
    {
        return new self(array_merge(['success' => false, 'error' => $message], $details), $status);
    }
}
