<?php

declare(strict_types=1);

use Jamarq\CpanelBackend\Auth\AuthAdapterInterface;
use Jamarq\CpanelBackend\Auth\AuthGuard;
use Jamarq\CpanelBackend\Config;
use Jamarq\CpanelBackend\Database\Database;
use Jamarq\CpanelBackend\Dotenv;
use Jamarq\CpanelBackend\Http\JsonResponse;
use Jamarq\CpanelBackend\Http\Request;
use Jamarq\CpanelBackend\Media\MediaResolver;
use Jamarq\CpanelBackend\Migrations\MigrationRunner;
use Jamarq\CpanelBackend\Routing\RouteFileBridge;
use Jamarq\CpanelBackend\Routing\Router;
use Jamarq\CpanelBackend\Storage\LocalStorageAdapter;
use Jamarq\CpanelBackend\Storage\R2StorageAdapter;
use Jamarq\CpanelBackend\Storage\StorageConfig;
use Jamarq\CpanelBackend\System\SystemChecks;
use Jamarq\CpanelBackend\Uploads\UploadValidator;
use Jamarq\CpanelBackend\Validation\Validator;

require __DIR__ . '/../vendor/autoload.php';

$tests = [];

function test(string $name, callable $callback): void
{
    global $tests;
    $tests[$name] = $callback;
}

function assertSameValue(mixed $expected, mixed $actual, string $message = ''): void
{
    if ($expected !== $actual) {
        throw new RuntimeException($message ?: sprintf('Expected %s, got %s', var_export($expected, true), var_export($actual, true)));
    }
}

function assertTrueValue(bool $actual, string $message = ''): void
{
    if (!$actual) {
        throw new RuntimeException($message ?: 'Expected true.');
    }
}

test('dotenv loads quoted and plain values', function (): void {
    $file = tempnam(sys_get_temp_dir(), 'dotenv-');
    file_put_contents($file, "APP_NAME=\"Test App\"\nPLAIN=value # comment\n");

    $loaded = Dotenv::load((string) $file, true);
    unlink((string) $file);

    assertSameValue('Test App', $loaded['APP_NAME']);
    assertSameValue('value', $loaded['PLAIN']);
});

test('config reads typed values', function (): void {
    $config = new Config(['PORT' => '3306', 'ENABLED' => 'true', 'NAME' => 'Site']);
    assertSameValue(3306, $config->int('PORT'));
    assertSameValue(true, $config->bool('ENABLED'));
    assertSameValue('Site', $config->required('NAME'));
});

test('request parses json and headers', function (): void {
    $request = new Request('post', '/api/test', [], ['Content-Type' => 'application/json'], '{"name":"Jason"}');
    assertSameValue('POST', $request->method());
    assertSameValue('application/json', $request->header('content-type'));
    assertSameValue('Jason', $request->json()['name']);
});

test('router dispatches path params', function (): void {
    $router = new Router();
    $router->get('/items/{id}', fn (Request $request, array $params): JsonResponse => JsonResponse::ok(['id' => $params['id']]));

    $response = $router->dispatch(new Request('GET', '/items/42'));
    $payload = json_decode($response->getBody(), true);

    assertSameValue(200, $response->getStatus());
    assertSameValue('42', $payload['id']);
});

test('router dispatches legacy colon path params', function (): void {
    $router = new Router();
    $router->get('/items/:id', fn (Request $request, array $params): JsonResponse => JsonResponse::ok(['id' => $params['id']]));

    $response = $router->dispatch(new Request('GET', '/items/43'));
    $payload = json_decode($response->getBody(), true);

    assertSameValue(200, $response->getStatus());
    assertSameValue('43', $payload['id']);
});

test('router supports site-specific not-found and exception handlers', function (): void {
    $router = new Router();
    $router
        ->onNotFound(fn (Request $request): JsonResponse => JsonResponse::error('missing', 404, ['site_code' => 'not_found']))
        ->onException(fn (Throwable $error, Request $request): JsonResponse => JsonResponse::error('broken', 503, ['site_code' => 'temporary']));
    $router->get('/boom', fn (): never => throw new RuntimeException('failed'));

    $missing = json_decode($router->dispatch(new Request('GET', '/missing'))->getBody(), true);
    $broken = json_decode($router->dispatch(new Request('GET', '/boom'))->getBody(), true);

    assertSameValue('not_found', $missing['site_code']);
    assertSameValue('temporary', $broken['site_code']);
});

test('route file bridge registers route files without changing route contents', function (): void {
    $dir = sys_get_temp_dir() . '/route-files-' . bin2hex(random_bytes(4));
    mkdir($dir);
    file_put_contents($dir . '/show.php', "<?php echo json_encode(['id' => \$_GET['id'] ?? null, 'mode' => \$_GET['mode'] ?? null]);");

    $router = new Router();
    $bridge = new RouteFileBridge($router, $dir);
    $bridge->map('GET', '/items/:id', 'show.php', ['mode' => 'read']);

    $response = $router->dispatch(new Request('GET', '/items/7'));
    $payload = json_decode($response->getBody(), true);

    unlink($dir . '/show.php');
    rmdir($dir);

    assertSameValue(200, $response->getStatus());
    assertSameValue('7', $payload['id']);
    assertSameValue('read', $payload['mode']);
});

test('router groups routes and applies middleware', function (): void {
    $router = new Router();
    $router->group('/admin', function (Router $admin): void {
        $admin->withMiddleware(
            fn (Request $request, callable $next): JsonResponse => $next($request->withAttribute('checked', true)),
            function (Router $guarded): void {
                $guarded->get('/health', fn (Request $request): JsonResponse => JsonResponse::ok([
                    'checked' => $request->attribute('checked'),
                ]));
            }
        );
    });

    $response = $router->dispatch(new Request('GET', '/admin/health'));
    $payload = json_decode($response->getBody(), true);

    assertSameValue(200, $response->getStatus());
    assertSameValue(true, $payload['checked']);
});

test('auth guard protects routes through an adapter', function (): void {
    $adapter = new class implements AuthAdapterInterface {
        public function userFromRequest(Request $request): ?array
        {
            return $request->header('authorization') === 'Bearer ok' ? ['id' => 1, 'role' => 'admin'] : null;
        }

        public function can(array $user, string $permission): bool
        {
            return $permission === 'admin';
        }
    };

    $router = new Router();
    $guard = new AuthGuard($adapter);
    $router->withMiddleware($guard->middleware('admin'), function (Router $protected): void {
        $protected->get('/admin', fn (Request $request): JsonResponse => JsonResponse::ok([
            'user_id' => $request->attribute('authUser')['id'] ?? null,
        ]));
    });

    $denied = json_decode($router->dispatch(new Request('GET', '/admin'))->getBody(), true);
    $allowed = json_decode($router->dispatch(new Request('GET', '/admin', [], ['Authorization' => 'Bearer ok']))->getBody(), true);

    assertSameValue(false, $denied['success']);
    assertSameValue(1, $allowed['user_id']);
});

test('validator collects field errors', function (): void {
    $validator = Validator::check(['email' => 'nope'])->required('name')->email('email');
    assertTrueValue(!$validator->passes());
    assertTrueValue(isset($validator->errors()['name']));
    assertTrueValue(isset($validator->errors()['email']));
});

test('upload validator allows text and blocks scripts', function (): void {
    $file = tempnam(sys_get_temp_dir(), 'upload-');
    file_put_contents($file, "hello\n");
    $validator = new UploadValidator(['max_bytes' => 1024]);

    assertSameValue([], $validator->validate([
        'name' => 'note.txt',
        'tmp_name' => $file,
        'size' => filesize((string) $file),
        'error' => UPLOAD_ERR_OK,
    ]));
    assertTrueValue($validator->validate([
        'name' => 'shell.php',
        'tmp_name' => $file,
        'size' => filesize((string) $file),
        'error' => UPLOAD_ERR_OK,
    ]) !== []);

    unlink((string) $file);
});

test('media resolver uses fallback when upload is missing', function (): void {
    $resolver = new MediaResolver();
    $result = $resolver->resolve('/uploads/missing.jpg', '/assets/default.jpg', fn (string $url): bool => $url !== '/uploads/missing.jpg');
    assertSameValue('/assets/default.jpg', $result['src']);
    assertSameValue('fallback', $result['status']);
});

test('system checks expose stable envelope', function (): void {
    $payload = (new SystemChecks())
        ->ok('api', 'API health', 'The API is responding.')
        ->warning('uploads', 'Uploads', 'Uploads are local.')
        ->toArray();

    assertSameValue(true, $payload['success']);
    assertSameValue('api', $payload['checks'][0]['id']);
});

test('migration runner applies pending sql files', function (): void {
    $pdo = new PDO('sqlite::memory:');
    $database = new Database($pdo);
    $dir = sys_get_temp_dir() . '/migrations-' . bin2hex(random_bytes(4));
    mkdir($dir);
    file_put_contents($dir . '/001_create_sample.sql', "CREATE TABLE sample (id INTEGER PRIMARY KEY, name TEXT);\nINSERT INTO sample (name) VALUES ('ok');\n");

    $runner = new MigrationRunner($database, $dir);
    $ran = $runner->runPending();
    $row = $database->fetch('SELECT name FROM sample WHERE id = 1');

    unlink($dir . '/001_create_sample.sql');
    rmdir($dir);

    assertSameValue(['001_create_sample.sql'], $ran);
    assertSameValue('ok', $row['name'] ?? null);
});

test('local storage adapter stores objects and reports public urls', function (): void {
    $dir = sys_get_temp_dir() . '/storage-' . bin2hex(random_bytes(4));
    mkdir($dir);
    $source = tempnam(sys_get_temp_dir(), 'source-');
    file_put_contents((string) $source, 'stored');

    $adapter = new LocalStorageAdapter($dir, '/uploads');
    $stored = $adapter->putFile('docs/test.txt', (string) $source, ['kind' => 'fixture']);

    assertSameValue('local', $stored->provider);
    assertSameValue('docs/test.txt', $stored->key);
    assertSameValue('/uploads/docs/test.txt', $stored->url);
    assertTrueValue($adapter->exists('docs/test.txt'));
    assertTrueValue($adapter->delete('docs/test.txt'));

    unlink((string) $source);
    rmdir($dir . '/docs');
    rmdir($dir);
});

test('storage config keeps r2 future-only until credentials exist', function (): void {
    $local = new StorageConfig([]);
    $ready = new StorageConfig([
        'MEDIA_STORAGE_PROVIDER' => 'r2',
        'R2_ENDPOINT' => 'https://account.r2.cloudflarestorage.com',
        'R2_PUBLIC_BUCKET' => 'public-bucket',
        'R2_PRIVATE_BUCKET' => 'private-bucket',
        'R2_ACCESS_KEY_ID' => 'key',
        'R2_SECRET_ACCESS_KEY' => 'secret',
        'R2_PUBLIC_BASE_URL' => 'https://cdn.example.com',
    ]);

    assertSameValue('local', $local->provider());
    assertSameValue(false, $local->r2Configured());
    assertSameValue('r2', $ready->provider());
    assertSameValue(true, $ready->r2Configured());
    assertSameValue('public-bucket', $ready->publicBucket());
    assertSameValue('private-bucket', $ready->privateBucket());
    assertSameValue('https://cdn.example.com', $ready->publicBaseUrl());
});

test('storage config preserves legacy single r2 bucket compatibility', function (): void {
    $config = new StorageConfig([
        'R2_ACCOUNT_ID' => 'account',
        'R2_BUCKET' => 'legacy-bucket',
        'R2_ACCESS_KEY_ID' => 'key',
        'R2_SECRET_ACCESS_KEY' => 'secret',
    ]);

    assertSameValue(true, $config->r2Configured());
    assertSameValue('https://account.r2.cloudflarestorage.com', $config->r2Endpoint());
    assertSameValue('legacy-bucket', $config->publicBucket());
    assertSameValue('legacy-bucket', $config->privateBucket());
});

test('r2 storage adapter reports cdn urls without leaking endpoint', function (): void {
    $adapter = new R2StorageAdapter(
        'https://account.r2.cloudflarestorage.com',
        'access-key',
        'secret-key',
        'site-media-public',
        'https://cdn.example.com'
    );

    assertSameValue('r2', $adapter->provider());
    assertSameValue('https://cdn.example.com/events/poster.jpg', $adapter->url('events/poster.jpg'));
});

$failed = 0;
foreach ($tests as $name => $callback) {
    try {
        $callback();
        echo "PASS {$name}\n";
    } catch (Throwable $error) {
        $failed++;
        fwrite(STDERR, "FAIL {$name}: {$error->getMessage()}\n");
    }
}

if ($failed > 0) {
    exit(1);
}

echo sprintf("%d tests passed.\n", count($tests));
