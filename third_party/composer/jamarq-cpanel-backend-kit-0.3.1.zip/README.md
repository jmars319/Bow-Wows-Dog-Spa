# cPanel Backend Kit

Shared PHP backend foundation for JAMARQ cPanel websites.

This package provides framework-light primitives for GoDaddy/cPanel PHP sites:

- environment and configuration loading
- HTTP request/response and JSON response helpers
- a small route dispatcher with route groups and middleware
- controller and auth guard helpers for compatibility-first site rewrites
- PDO convenience helpers
- validation, audit logging, upload validation, media fallback resolution
- local and Cloudflare R2 media storage interfaces
- system checks and SQL migration utilities

The package intentionally does not contain client-specific routes, schemas, payment logic, or business workflows.

## Requirements

- PHP 8.3+
- Composer 2+

## Install In A Site Repo

Add the private VCS repository to the site backend `composer.json`:

```json
{
  "repositories": [
    {
      "type": "vcs",
      "url": "https://github.com/jmars319/cpanel-backend-kit"
    }
  ],
  "require": {
    "jamarq/cpanel-backend-kit": "^0.2"
  }
}
```

Run Composer locally before building the cPanel deploy zip. Deploy artifacts should include `api/vendor` and should not require Composer to run on the server.

## Storage Providers

The package is local-storage first, with R2 support behind the same adapter interface. `LocalStorageAdapter` writes to the existing cPanel uploads tree. `R2StorageAdapter` writes through Cloudflare R2's S3-compatible API and returns CDN URLs only when a public base URL is configured.

Use `local` as the fallback provider until a site has been copied to R2 and manually verified. When R2 is active, keep local uploads readable as legacy fallback and route all new upload writes through the storage adapter.

- `MEDIA_STORAGE_PROVIDER=local`
- `R2_ENDPOINT`
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`
- `R2_PUBLIC_BUCKET`
- `R2_PRIVATE_BUCKET`
- `R2_PUBLIC_BASE_URL=https://cdn.example.com`

Legacy single-bucket projects may still use `R2_ACCOUNT_ID` plus `R2_BUCKET`; new site integrations should use explicit public/private bucket names.

## Verify

```bash
composer install
composer validate --strict
composer lint
composer test
composer verify
composer audit --locked
just security
```

## Local Standards

- Use PHP 8.3+ and Composer 2+.
- `just verify` runs strict Composer validation plus the package verification command.
- `just security` runs GitHub Actions validation plus Composer's locked advisory audit.
- Package versions are represented by Git tags such as `v0.3.0`; do not add a static Composer `version` field.
- Build output, dependency folders, local env files, logs, database dumps, and secrets stay out of Git.
